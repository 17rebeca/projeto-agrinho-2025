let plantX, plantY;
let growth = 0;

function setup() {
  createCanvas(600, 400);
  plantX = width / 2;
  plantY = height - 50;
}

function draw() {
  background(220);
  
  // Desenho do solo
  fill(139, 69, 19);
  rect(0, height - 50, width, 50);
  
  // Desenho da planta
  fill(34, 139, 34);
  let plantHeight = growth * 100;
  rect(plantX - 10, plantY - plantHeight, 20, plantHeight);
  
  // Texto informativo
  fill(0);
  textSize(16);
  text("Clique para fazer a planta crescer!", 20, 30);
  
  // Mostrar o nível de crescimento
  text("Crescimento: " + nf(growth * 100, 1, 0) + "%", 20, 50);
}

function mousePressed() {
  // Cada clique faz a planta crescer até um limite
  if (growth < 1) {
    growth += 0.1;
  }
}
